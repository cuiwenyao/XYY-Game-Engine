#include "./GlobalLogicDriver.h"

void XYY_GlobalLogicDriver::init()
{
	// game init

}

void XYY_GlobalLogicDriver::run(XYY_SceneContent * sc)
{
	// game running

}