//XYY_Game_Engine.cpp
#include "XYY_Game_Engine.h"
extern "C" _declspec(dllexport)void start()
{
	;
}