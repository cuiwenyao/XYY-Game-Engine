//XYY_Game_Engine.h
#ifndef XYY_Game_Engine_H
#define XYY_Game_Engine_H
extern "C" _declspec(dllexport) void start();
#endif
